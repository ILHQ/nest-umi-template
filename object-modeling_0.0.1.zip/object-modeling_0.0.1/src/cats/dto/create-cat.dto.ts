export class CreateCatDto {
  name: string;
  age: number;
  breed: string;
  id: number;
}
