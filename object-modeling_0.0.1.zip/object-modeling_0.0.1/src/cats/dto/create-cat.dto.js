"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCatDto = void 0;
var CreateCatDto = /** @class */ (function () {
    function CreateCatDto() {
    }
    return CreateCatDto;
}());
exports.CreateCatDto = CreateCatDto;
