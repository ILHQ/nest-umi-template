"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmiController = void 0;
var common_1 = require("@nestjs/common");
var http_exception_filter_1 = require("../http-exception.filter");
var env_1 = require("../../env");
var fs_1 = require("fs");
var pkg = JSON.parse((0, fs_1.readFileSync)('./package.json', 'utf-8'));
var UmiController = function () {
    var _classDecorators = [(0, common_1.Controller)(), (0, common_1.UseFilters)(http_exception_filter_1.AllExceptionsFilter)];
    var _classDescriptor;
    var _classExtraInitializers = [];
    var _classThis;
    var _instanceExtraInitializers = [];
    var _getPath_decorators;
    var _getHealth_decorators;
    var _proxyDevServer_decorators;
    var _proxyAssets_decorators;
    var _proxySpacialModeling_decorators;
    var _proxySetCenter_decorators;
    var _getIndex_decorators;
    var UmiController = _classThis = /** @class */ (function () {
        function UmiController_1(umiService) {
            this.umiService = (__runInitializers(this, _instanceExtraInitializers), umiService);
        }
        UmiController_1.prototype.getPath = function () { };
        UmiController_1.prototype.getHealth = function () {
            return this.umiService.getHealth();
        };
        UmiController_1.prototype.proxyDevServer = function (req, res) {
            var proxy = this.umiService.proxyDevServer();
            proxy(req, res, function (result) {
                if (result instanceof Error) {
                    throw result;
                }
            });
        };
        UmiController_1.prototype.proxyAssets = function (req, res) {
            var proxy = this.umiService.proxyAssets();
            proxy(req, res, function (result) {
                if (result instanceof Error) {
                    throw result;
                }
            });
        };
        UmiController_1.prototype.proxySpacialModeling = function (req, res) {
            var proxy = this.umiService.proxySpacialModeling();
            proxy(req, res, function (result) {
                if (result instanceof Error) {
                    throw result;
                }
            });
        };
        UmiController_1.prototype.proxySetCenter = function (req, res) {
            var proxy = this.umiService.proxySetCenter();
            proxy(req, res, function (result) {
                if (result instanceof Error) {
                    throw result;
                }
            });
        };
        UmiController_1.prototype.getIndex = function () {
            return {
                title: pkg.description,
                routerPrefix: env_1.default.routerPrefix,
                env: env_1.default.env,
                publicPath: env_1.default.assetsPublicPath,
                imgDomain: env_1.default.imgDomain,
                cndDomain: env_1.default.cndDomain,
                proxyPrefix: env_1.default.proxyPrefix,
            };
        };
        return UmiController_1;
    }());
    __setFunctionName(_classThis, "UmiController");
    (function () {
        var _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        _getPath_decorators = [(0, common_1.Get)(), (0, common_1.Redirect)(env_1.default.appPrefix, 302)];
        _getHealth_decorators = [(0, common_1.Get)("/health")];
        _proxyDevServer_decorators = [(0, common_1.Get)("/dev-server/*")];
        _proxyAssets_decorators = [(0, common_1.Get)("".concat(env_1.default.appPrefix, "/assets/dist/*"))];
        _proxySpacialModeling_decorators = [(0, common_1.All)("".concat(env_1.default.proxyPrefix, "/spacial-modeling/*"))];
        _proxySetCenter_decorators = [(0, common_1.All)("".concat(env_1.default.proxyPrefix, "/set-center/*"))];
        _getIndex_decorators = [(0, common_1.Get)(env_1.default.appPrefix + '/*'), (0, common_1.Render)('index')];
        __esDecorate(_classThis, null, _getPath_decorators, { kind: "method", name: "getPath", static: false, private: false, access: { has: function (obj) { return "getPath" in obj; }, get: function (obj) { return obj.getPath; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _getHealth_decorators, { kind: "method", name: "getHealth", static: false, private: false, access: { has: function (obj) { return "getHealth" in obj; }, get: function (obj) { return obj.getHealth; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _proxyDevServer_decorators, { kind: "method", name: "proxyDevServer", static: false, private: false, access: { has: function (obj) { return "proxyDevServer" in obj; }, get: function (obj) { return obj.proxyDevServer; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _proxyAssets_decorators, { kind: "method", name: "proxyAssets", static: false, private: false, access: { has: function (obj) { return "proxyAssets" in obj; }, get: function (obj) { return obj.proxyAssets; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _proxySpacialModeling_decorators, { kind: "method", name: "proxySpacialModeling", static: false, private: false, access: { has: function (obj) { return "proxySpacialModeling" in obj; }, get: function (obj) { return obj.proxySpacialModeling; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _proxySetCenter_decorators, { kind: "method", name: "proxySetCenter", static: false, private: false, access: { has: function (obj) { return "proxySetCenter" in obj; }, get: function (obj) { return obj.proxySetCenter; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _getIndex_decorators, { kind: "method", name: "getIndex", static: false, private: false, access: { has: function (obj) { return "getIndex" in obj; }, get: function (obj) { return obj.getIndex; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        UmiController = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return UmiController = _classThis;
}();
exports.UmiController = UmiController;
